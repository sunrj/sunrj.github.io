---
permalink: /academia-services
title: "Academia Services"
excerpt: "Academia Services"
author_profile: true
---
1. (External) Journal Reviewer: Journals: TKDE, TKDD.
2. Conferences: SIGMOD, VLDB, ICDE, KDD, WSDM, CIKM, DASFAA, etc.
3. Organizing Committee: Publicity Chair of [LSGDA 2020](https://www.google.com/url?q=https%3A%2F%2Flsgda.github.io%2F2020%2F&sa=D&sntz=1&usg=AFQjCNFYfkgg9wBrWW8wUaG8GCGXJz3z_A)

