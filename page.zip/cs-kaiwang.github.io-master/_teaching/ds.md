---
title: "Data Science and Decisions"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/ds
venue: "UNSW"
date: 2017-01-01
location: "Sydney NSW"
---

Teaching Data Science and Decisions -  2017 S2, 2018 S2*, 2019 T2*
ps: * indicates course coordinator