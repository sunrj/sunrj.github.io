---
title: "Efficient computing of radius-bounded k-cores"
collection: publications
permalink: /publication/Efficient-computing-of-radius-bounded-k-cores
date: 16/04/2018
venue: '2018 IEEE 34th International Conference on Data Engineering (ICDE)'
paperurl: 'https://ieeexplore.ieee.org/abstract/document/8509251/'
citation: 'Wang, K., Cao, X., Lin, X., Zhang, W., & Qin, L. (2018, April). Efficient computing of radius-bounded k-cores. In 2018 IEEE 34th International Conference on Data Engineering (ICDE) (pp. 233-244). IEEE.'
---
